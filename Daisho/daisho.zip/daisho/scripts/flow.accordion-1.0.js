jQuery(document).ready(function() {
	jQuery("#accordion").accordion();
});
