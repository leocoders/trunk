<!DOCTYPE html>
<html <?php language_attributes(); ?> xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
	<?php
	global $mobile;
	global $ipad;
	global $desktop;
	if(strstr($_SERVER['HTTP_USER_AGENT'],'iPad')){ $ipad = true; }
	if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone')){ $mobile = true; }
	if(strstr($_SERVER['HTTP_USER_AGENT'],'iPod')){ $mobile = true; }
	if(strstr($_SERVER['HTTP_USER_AGENT'],'Android')){ $mobile = true; }
	if(!$mobile AND !$ipad){ $desktop = true; } ?>
	<?php if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPod') || strstr($_SERVER['HTTP_USER_AGENT'],'Android')){ ?>
	<meta name="viewport" content="user-scalable=yes, width=735" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<?php }else if(strstr($_SERVER['HTTP_USER_AGENT'],'iPad')){ ?>
	<meta name="viewport" content="user-scalable=yes, width=980" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<?php } ?>
	<title><?php
		if(is_home()) {
		echo bloginfo('name').' - Home';
		} elseif(is_category()) {
		echo 'Browsing the Category ';
		wp_title(' ', true, '');
		} elseif(is_archive()){
		echo 'Browsing Archives of';
		wp_title(' ', true, '');
		} elseif(is_search()) {
		echo 'Search Results for "'.$s.'"';
		} elseif(is_404()) {
		echo '404 - Page got lost!';
		} else {
		wp_title('-', true, 'right'); bloginfo('name'); 
		} ?></title>
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<link rel="shortcut icon" href="<?php $custom_favicon=get_option("custom_favicon"); print((($custom_favicon)?$custom_favicon:bloginfo('template_directory')."/images/favicon.ico")); ?>" />
	<?php //if(!get_option("disable_css")){ ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('template_directory'); ?>/reset.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('template_directory'); ?>/fonts.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('stylesheet_url'); ?>" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('template_directory'); ?>/grid.css" />
	<link href='http://fonts.googleapis.com/css?family=Dosis:400,800,700,600,500,300,200' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Lato:400,700,400italic,900,300italic,300,100,700italic' rel='stylesheet' type='text/css'>
	<?php //} ?>
	<?php wp_head(); ?>
	<!--[if IE]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js" type="text/javascript"></script>
	<![endif]-->
	<?php
	$custom_css_style = get_option("custom_css_style");
	if($custom_css_style){
		print("<style type=\"text/css\">".$custom_css_style."</style>");
	}
	?>
	
	<?php
	if($_GET['prj'] == 'classic') { $_SESSION['prj'] = 0; }
	if($_GET['prj'] == 'thumb') { $_SESSION['prj'] = 1; }
	$portfolio_mode 	= 	get_option('portfolio_mode'); // 1 = thumbnail grid, 0 = classic
	if(isset($_SESSION['prj']) && ($_SESSION['prj'] == 0)){ $portfolio_mode = 0; }
	if(isset($_SESSION['prj']) && ($_SESSION['prj'] == 1)){ $portfolio_mode = 1; }
	if($portfolio_mode == '1'){ ?>
	<style type="text/css">
	@media (min-width: 950px) and (max-width: 1240px) {
		#header .inner, .welcome-text, #footer .inner, .footer-bottom, .tn-grid-container, .info-box .info-box-inner { width: 900px; }
	}
	@media (min-width: 750px) and (max-width: 950px) {
		#header .inner, .welcome-text, #footer .inner, .footer-bottom, .tn-grid-container, .info-box .info-box-inner { width: 675px; }
	}
	@media (max-width: 950px) {
		#main-nav-compact { display: none; } 
		.menu-mobile-menu-container { display: block; }
		#menu{ display: none; }
		#main-nav { margin-top: 25px; position: absolute; top: 0; width: 75%; }
		#header { min-height: 100px; position: fixed; border-bottom: 1px solid #AAAAAA; box-shadow: 0 0 8px #888888; }
		#header .inner { border-bottom: 0 none; min-height: 100px; }
		body { padding-top: 120px!important; }
		#footer .inner { display: none; }
		.homepage-project-list { position: static!important; border-bottom: 0 none; padding-top: 20px; margin-bottom: 20px !important; }
		#footer { position: relative; width: 100%;
		background-image: linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
		background-image: -o-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
		background-image: -moz-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
		background-image: -webkit-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
		background-image: -ms-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
		background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, rgb(25,23,24)), color-stop(1, rgb(49,47,48)));
		border-top: 1px solid #131313; box-shadow: 0px 5px 30px rgba(0,0,0,0.8); -webkit-box-shadow: -5px -5px 5px rgba(0,0,0,0.8); opacity:1; }
		#footer_copyright { float: left; width: 100%; text-align: center; padding-bottom: 0; font-size: 16px; }
		.footer_widgets { float: left; width: 100%; text-align: center; }
		.footer-bottom { margin: 8px auto 40px; }
		.footer-bottom-widgets { display: inline-block; float: none; margin-top: 15px; }
		#social { padding-bottom: 10px; padding-top: 12px; float: left; }
		#social a { float:left; position:relative; text-decoration:none; width:37px; height: 37px; clear:both; }
		#social li { float:left; width: 37px; margin-left: 22px; margin-right: 22px; }
		#social a span { cursor:pointer; display:block; left:0; position:absolute; top:0; font-size: 37px; color: #a6aAaB; }
		#footer {
			border-top: 1px solid #BBBBBB;
			background-image: linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -o-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -moz-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -webkit-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -ms-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #DADADA), color-stop(1, #F4F4F4));
			 box-shadow: 0 5px 30px rgba(0, 0, 0, 0.4);
			-webkit-box-shadow: -5px -5px 5px rgba(0, 0, 0, 0.15);
		}
		#header {
			background-image: linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -o-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -moz-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -webkit-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -ms-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
			background-image: -webkit-gradient( linear, left bottom, left top, color-stop(0, #DADADA), color-stop(1, #F4F4F4));
		}
	}
	</style>
	<?php }else{ ?>
	<style type="text/css">
	@media (max-width: 1260px) {
		#header .inner, .welcome-text, #footer .inner, .footer-bottom, .page-content, .recent-blog-container, .slideshow-project-excerpt, .info-box .info-box-inner { max-width: 1000px!important; }
		.recent-heading-container { max-width: 1005px; }
		.element { height: 133px; width: 196px; }
		#footer .inner .grid_12 img { float: left; margin: 0 1%; max-width: 220px; width: 18%; }
	}
	@media (max-width: 1150px) {
		#header .inner, .welcome-text, #footer .inner, .footer-bottom, .page-content, .recent-blog-container, .slideshow-project-excerpt, .info-box .info-box-inner { max-width: 900px!important; }
		.recent-heading-container { max-width: 905px; }
		.element { height: 120px; width: 176px; }
	}
	@media (max-width: 1050px) {
		#header .inner, .welcome-text, #footer .inner, .footer-bottom, .page-content, .recent-blog-container, .slideshow-project-excerpt, .info-box .info-box-inner { max-width: 800px!important; }
		.recent-heading-container { max-width: 805px; }
		.element { height: 133px; width: 196px; }
		.element:last-child { display: none; }
	}
	@media (max-width: 950px) {
		.element { height: 133px; margin: 0 0.25%; width: 24.5%; }
		.element:last-child { display: none; }
		.related-posts-home .related-posts-title { width: 43%; }
		.recent-blog-container { margin: 0 auto 50px!important; }
	}
	</style>
	<?php } ?>
	
	<?php 
	$args = array( 'post_type' => 'slideshow' );
	$recent = new WP_Query( $args );
	while($recent->have_posts()) : $recent->the_post();
	
	// Set variables
	if(get_post_meta($post->ID, 'slide-image', true)){ $slide_image = get_post_meta($post->ID, 'slide-image', true); }else{ unset($slide_image); }
	if(get_post_meta($post->ID, 'slide-button-x-offset', true)){ $slide_button_x_offset = get_post_meta($post->ID, 'slide-button-x-offset', true); }else{ $slide_button_x_offset = '0px'; }
	if(get_post_meta($post->ID, 'slide-button-y-offset', true)){ $slide_button_y_offset = get_post_meta($post->ID, 'slide-button-y-offset', true); }else{ $slide_button_y_offset = '0px'; }
	if(get_post_meta($post->ID, 'slide-button-icon', true)){ $slide_button_icon = get_post_meta($post->ID, 'slide-button-icon', true); }else{ unset($slide_button_icon); }
	if(get_post_meta($post->ID, 'slide-color', true)){ $slide_color = get_post_meta($post->ID, 'slide-color', true); }else{ $slide_color = '#00a4a7'; }
	if(get_post_meta($post->ID, 'slide-text-color', true) == '#464646'){ $slide_text_color_title = 'slideshow-project-title-dark'; $slide_text_color_desc = 'slideshow-project-desc-dark'; $slide_button_dark = '#464646'; }else{ unset($slide_text_color_title); unset($slide_text_color_desc); $slide_button_dark = '#f1f1f1'; }
	if(isset($slide_id)){ $slide_id++; }else{ $slide_id = 0; }
	
	//Display slides
	if($slide_image){ $button_styles .='
	<style type="text/css">
#slide_'.$slide_id.' .button {
	position:			absolute;
	right:				'.$slide_button_x_offset.';
	top:				'.$slide_button_y_offset.';
	color: 				'.$slide_button_dark.'!important;
	font-family:		\'Open Sans\', Arial, sans-serif;
	font-weight: 		900;
	text-shadow:		0px 2px 2px #fff inset;
	text-shadow:		0px -1px 0px '.hexDarker($slide_color, 8).';
	text-transform:		uppercase;
	padding: 			0.7em 1em 0.7em;
	-webkit-border-radius: 	2em 2em 2em 2em;
	-moz-border-radius: 	2em 2em 2em 2em;
	border-radius: 			2em 2em 2em 2em;
	background-color: 	'.$slide_color.';
	background-image: 	-moz-linear-gradient(center top , rgba(255, 255, 255, 0.75) 0%, rgba(255, 255, 255, 0) 75%, rgba(255, 255, 255, 0.25) 100%);
	background-image: 	-webkit-linear-gradient(top, rgba(255, 255, 255, 0.75) 0%, rgba(255, 255, 255, 0) 75%, rgba(255, 255, 255, 0.25) 100%);
	background-image: 	linear-gradient(top, rgba(255, 255, 255, 0.75) 0%, rgba(255, 255, 255, 0) 75%, rgba(255, 255, 255, 0.25) 100%);

}
#slide_'.$slide_id.' .button:hover { background-color: '.hexDarker($slide_color, 10).'; text-decoration: none; }
	</style>'; ?>
	<?php } ?>
	<?php endwhile; wp_reset_query(); ?>
<?php echo $button_styles; ?>
<?php  if(get_option("flow_featured_slideshow") == 0 AND !$mobile){ ?>
<style type="text/css">
	body { opacity: 0; }
	#konzept_slideshow { width:100%; position: relative; z-index: 999999; top: 0; height: 330px; overflow: visible; top: -33px; }
	
	/* Overflow hidden without cropped images workaround */
	#konzept_slideshow { width:100%; position: relative; z-index: 999999; top: 0; height: 330px; overflow: visible; top: -33px; margin-top: -30px; padding-top: 30px; overflow: hidden;  }
	
	#konzept_slideshow * { max-height: 330px; overflow: visible!important; }
	#scroller { float:left; padding: 0 0 0 0; }
	#scroller ul { list-style:none; display:block; float:left; width:21000px; }
	#scroller li { float:left; margin: 0; position: relative; overflow: hidden; }
	#scroller li img { left: 0; margin: auto; max-height: 450px; position: absolute; right: 0; top: -81px; }
	.slideshow-project-excerpt { display: block; left: 0; margin: auto; max-width: 1120px; position: absolute; right: 0; top: 0; width: 92%; z-index: 2143833; }
	.slideshow-project-title { color: #F8F8F8; font-family: 'Open Sans',Arial,sans-serif; font-size: 65px; line-height: 55px; margin-bottom: 2%; margin-top: 0; width: 100%; word-wrap: break-word; font-weight: 900; width: 38%; }
	.slideshow-project-title-dark { color: #222222; }
	.slideshow-project-desc-dark { color: #464646!important; }
	.imgscontainer { opacity: 0; }
	.project-description-home { font-family: 'Open Sans',Arial,sans-serif; font-weight: 400; font-size: 22px; color: #ffffff; width: 40%; }
	
	.videoBG_wrapper { width: inherit; height; inherit; }
	.videoBG { width: inherit; height; inherit; }
	.videoBG video { }
	.project-more { position: relative; z-index: 99999999; }
	
	@media (max-width: 1440px) {
		.slideshow-project-title { font-size: 55px; line-height: 45px; margin-bottom: 1%; }
		.project-more { font-size: 26px; margin-top: 5%; }
	}	
	@media (max-width: 1200px) {
		.slideshow-project-title { font-size: 50px; line-height: 42px; }
		.project-description { font-size: 20px; }
		.project-more { font-size: 22px; }
	}	
	@media (max-width: 900px) {
		.slideshow-project-title { font-size: 45px; line-height: 37px; }
		.project-more { font-size: 20px; margin-top: 7%; }
	}
	.konzept_arrow_left { position: absolute; }
	.konzept_arrow_right { position: absolute; }
	.excerpt-clone { z-index: auto; }
	.excerpt-clone a { position: absolute!important; bottom: 0!important; z-index: 13242323; color: #3B95B1; display: block; float: left; font-family: 'Open Sans',Arial,sans-serif; margin-top: 7%; }
</style>
<?php } ?>
<script type="text/javascript">
	function info_box_resize(){
		var info_box_height = jQuery('.info-box').height();
		jQuery('.info-box').css({ 'margin-top' : ~info_box_height+5 });
		$(".info-box").hover(
		  function () {
			$(this).stop().animate({ 'margin-top' : 0 }, 300);
		  },
		  function () {
			$(this).stop().animate({ 'margin-top' : ~info_box_height+5 }, 300);
		  }
		);
	}
	function videojsvolumemuteclick(){
		jQuery(".vjs-volume-control").click(function() {
			if(jQuery(".video-js").prop('muted')){
				jQuery(".video-js").prop('muted', false).prop('volume', 1);
			}else{
				jQuery(".video-js").prop('muted', true).prop('volume', 0);
			}
		});
	}
	
jQuery(window).load(function(){
	try{
		videojsvolumemuteclick();
	}catch(e){}
});
jQuery(document).ready(function(){
	jQuery('body').animate({ 'opacity' : 1 }, 700);
	info_box_resize();
	$(window).resize(function(){
		info_box_resize();
	});

	resizeimageslide($("#myimage_original"),false,false);
	function resizeimageslide(ielement,isvideo,chkpushwidthtoarr){
		var iel = $(ielement);
		
		/* Create slideshow container, var winheight is height() fix for iPhone */
		var winheight = window.innerHeight ? window.innerHeight:$(window).height();
		//var fg_imgareaw = $(window).width()/*((portfoliofixedmenum==3)?($(window).width()-220):$(window).width())*/ /*-10*/, fg_imgareah = $(window).height();
		var fg_imgareaw = $(window).width()/*((portfoliofixedmenum==3)?($(window).width()-220):$(window).width())*/ /*-10*/, fg_imgareah = winheight;
		var fg_imgsize = [iel.width(), iel.height()];
		var fg_fitscreen = false;
		if(iel.hasClass("slide_horizontal")){
			fg_fitscreen = true;
		}
		if(isvideo){
			fg_imgsize = [16,9];
		}
		if(iel.is("div")){
			fg_imgsize = [fg_imgareaw, fg_imgareah];
			resizeimageslide($("img:not(.myimage)", iel),false,false);
		}
		if(fg_imgsize[0] && fg_imgsize[1] && fg_imgareaw && fg_imgareah){
			//if(fg_imgsize[0] < fg_imgareaw || fg_imgsize[1] < fg_imgareah){
			var fg_imgnewsizew=0, fg_imgnewsizeh=0;
			var fg_imgscalerx = fg_imgsize[0]/fg_imgareaw, fg_imgscalery = fg_imgsize[1]/fg_imgareah;
			if(fg_fitscreen){
				if(fg_imgscalerx <= fg_imgscalery){
					fg_imgnewsizew = fg_imgsize[0]/fg_imgscalery;
					fg_imgnewsizeh = fg_imgsize[1]/fg_imgscalery;
				}else{
					fg_imgnewsizew = fg_imgsize[0]/fg_imgscalerx;
					fg_imgnewsizeh = fg_imgsize[1]/fg_imgscalerx;
				}
			}else{
				if(fg_imgscalerx <= fg_imgscalery){
					fg_imgnewsizew = fg_imgsize[0]/fg_imgscalerx;
					fg_imgnewsizeh = fg_imgsize[1]/fg_imgscalerx;
				}else{
					fg_imgnewsizew = fg_imgsize[0]/fg_imgscalery;
					fg_imgnewsizeh = fg_imgsize[1]/fg_imgscalery;
				}
			}
			if(fg_imgnewsizew && fg_imgnewsizeh){
				fg_imgnewsizew = Math.floor(fg_imgnewsizew);
				fg_imgnewsizeh = Math.floor(fg_imgnewsizeh);
				if(!isvideo){
					if(fg_fitscreen){
						if(fg_imgscalerx <= fg_imgscalery){
							iel.css({'top':'0px', 'left':'0px', 'width':fg_imgnewsizew+'px', 'height':fg_imgnewsizeh+'px'});
							iel.parent().css({'width':fg_imgnewsizew+'px', 'height':fg_imgnewsizeh+'px'});
						}else{
							iel.css({'top':Math.floor((fg_imgareah-fg_imgnewsizeh)/2)+'px', 'left':(Math.floor((fg_imgareaw-fg_imgnewsizew)/2))+'px', 'width':fg_imgnewsizew+'px', 'height':fg_imgnewsizeh+'px'});
						}
						if(chkpushwidthtoarr){
							if(fg_imgscalerx <= fg_imgscalery){
								portfolioslideswidths[portfolioslideswidths.length] = fg_imgnewsizew;
							}else{
								portfolioslideswidths[portfolioslideswidths.length] = fg_imgareaw;
							}
						}
					}else{
						//console.log(iel);
						//console.log("top: "+Math.floor((fg_imgareah-fg_imgnewsizeh)/2)+" left: "+(Math.floor((fg_imgareaw-fg_imgnewsizew)/2))+" width: "+fg_imgnewsizew+" height: "+fg_imgnewsizeh+".");
						iel.css({'top':Math.floor((fg_imgareah-fg_imgnewsizeh)/2)+'px', 'left':(Math.floor((fg_imgareaw-fg_imgnewsizew)/2))+'px', 'width':fg_imgnewsizew+'px', 'height':fg_imgnewsizeh+'px'});
						if(chkpushwidthtoarr){
							portfolioslideswidths[portfolioslideswidths.length] = fg_imgareaw;
						}
					}
				}else{
					$(".video-js", iel).css({'top':Math.floor((fg_imgareah-fg_imgnewsizeh)/2)+'px', 'left':(Math.floor((fg_imgareaw-fg_imgnewsizew)/2))+'px', 'width':fg_imgnewsizew+'px', 'height':fg_imgnewsizeh+'px'});
					if(chkpushwidthtoarr){
						portfolioslideswidths[portfolioslideswidths.length] = fg_imgareaw;
					}
				}
			}
		}else{
			return false;
		}
		return true;
	}
});
jQuery(document).ready(function(){
	$('#mobile_menu').change(function(e){
		window.location = $(this).val();
	})
	$('#mobile_menu .mob-sub').hide();
});
</script>
<?php
//if(get_option("bgchanger_color")){
//	print("<style type=\"text/css\">body{background-color:".get_option("bgchanger_color")."!important;}</style>");
//	print("<style type=\"text/css\">.portfolio-fs-slide{background-color:".get_option("bgchanger_color").";} .portfolio-fs-slide:first-child { background-color: none; }</style>");
//}
	//if($_GET['style'] == 'dark') { $_SESSION['stylemode']=0; }
	//if($_GET['style'] == 'light') { $_SESSION['stylemode']=1; }
	//$cur_style = get_option("website_style");
	//if(isset($_SESSION['stylemode']) && ($_SESSION['stylemode'] == 0)){ $cur_style = 0; }
	//if(isset($_SESSION['stylemode']) && ($_SESSION['stylemode'] == 1)){ $cur_style = 1; }
	//if ($cur_style == 1) { ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('template_directory'); ?>/light.css" />
<?php //} ?>
</head>

<body <?php if(!isset($class)){ $class = ''; } body_class( $class ); ?>>

<div class="header-search-form" style="display:none;"><div class="header-search-label">Search</div><?php get_search_form(); ?></div>
<div class="loading"></div>
<?php if((($bgcval_bi = get_option("bgchanger_imgsrc") and get_option("bgchanger_imgsrc") != '') or ($bgcval_bi2 = get_post_meta($post->ID, 'bg_image', true)))) { ?>
<img src="<?php if($bgcval_bi2){echo $bgcval_bi2;}elseif($bgcval_bi = get_option("bgchanger_imgsrc") and get_option("bgchanger_imgsrc") != ''){echo $bgcval_bi;}else{echo'';} ?>" alt="" id="myimage_original" style="display: block; overflow: hidden; position: fixed;z-index:-1; opacity:0;">

<?php } ?>
<header id="header">
	<div class="inner clearfix">
	<?php $logo_type = get_option('logo_type');
	if(preg_match('/^.*\.(jpg|jpeg|png|gif|ico)$/i', $logo_type)){
		$blog_url = get_home_url();
		$blog_desc = get_bloginfo('description');
		echo "<div id=\"logo-image\"><a title=\"". $blog_desc ."\" href=\"". $blog_url ."\"><img src=\"".$logo_type."\" alt=\"" . $blog_desc . "\" /></a><div class=\"clear\"></div></div>";
	} else { ?>
	<div id="logo-text">
		<div class="logo-text-inner">
			<h1><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
			<?php if(get_option('tagline_disable') == 0){ ?>
			<div id="tagline">
				<a rel="home" title="<?php bloginfo('description'); ?>" href="<?php bloginfo('url'); ?>"><?php bloginfo('description'); ?></a>
			</div>
			<?php } ?>
			<div class="clear"></div>
		</div>
	</div>
	<?php } ?>
	<nav id="main-nav">
		<!--<div class="menu-col clearfix">-->
		<div class="clearfix">
			<?php wp_nav_menu( array( 'sort_column' => 'menu_order', 'theme_location'=>'main_menu', 'menu_class'=>'sf-menu sf-js-enabled sf-shadow', 'menu_id'=>'menu', 'walker' => new description_walker() ) ); ?>
			<?php wp_nav_menu(array( 'sort_column' => 'menu_order', 'theme_location'=>'mobile_menu', 'menu_id'=>'mobile_menu', 'items_wrap' => '<select name="-Menu-" id="%1$s" class="%2$s">%3$s</select>', 'walker' => new select_menu_walker() )); ?>
		</div>
		<!--<div class="menu-col clearfix">
			<div class="menu-title">WORKS</div>
			<ul class="pf_nav">
				<li <?php if(is_home() or is_singular("portfolio")){ echo 'class="selected"'; } ?>><a title="all" href="#">ALL WORKS</a></li>
				<?php
					$arraycatss = get_terms("portfolio_category");
					$arrcatsnested = array();
					$arrcatgli = 0;
					foreach($arraycatss as $arraycatss_a){
						if($arraycatss_a->parent == 0){
							$arrcatsnested[$arrcatgli] = array('obj'=>$arraycatss_a, 'childobjs'=>array());
							foreach($arraycatss as $arraycatss_achild){
								if($arraycatss_achild->parent == $arraycatss_a->term_id){
									$arrcatsnested[$arrcatgli]['childobjs'][] = $arraycatss_achild;
								}
							}
							$arrcatgli++;
						}
					}
					//foreach($arraycatss as $arraycatss_a){
						//echo '<li><a title="'.$arraycatss_a->slug.'" href="javascript:void(null);">'.$arraycatss_a->name.'</a></li>';
					//}
					for($ci=0;$ci<count($arrcatsnested);$ci++){
						print('<li'.((count($arrcatsnested[$ci]['childobjs'])?" class=\"menuhoversubcats\"":"")).'><a title="'.$arrcatsnested[$ci]['obj']->slug.'" href="javascript:void(null);">'.$arrcatsnested[$ci]['obj']->name.'</a>');
						if(count($arrcatsnested[$ci]['childobjs'])){
							print("<ul style=\"display:none;\">");
							for($cj=0;$cj<count($arrcatsnested[$ci]['childobjs']);$cj++){
								print('<li><a title="'.$arrcatsnested[$ci]['childobjs'][$cj]->slug.'" href="javascript:void(null);">'.$arrcatsnested[$ci]['childobjs'][$cj]->name.'</a></li>');
							}
							print("</ul>");
						}
						print("</li>");
					}
				?>
			</ul>
		</div>-->
		<div class="clear"></div>
	</nav>
</div> <!-- /.inner -->
</header>
<?php 
$info_box_page = get_option('info_box');
	if($page_id = $info_box_page){
		$page_data = get_page( $page_id );
?>
<div class="info-box">
	<div class="info-box-inner clearfix container_12">
				<?php echo do_shortcode($page_data->post_content); ?>
		<img src="<?php bloginfo('template_directory'); ?>/images/header-arrow.png" class="header-arrow">
	</div>
</div>
<?php } ?>