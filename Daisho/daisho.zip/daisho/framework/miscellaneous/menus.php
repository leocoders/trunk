<?php 
	// Create WP3 menu areas
	register_nav_menus( array('main_menu' => 'Main Menu', 'compact_menu' => 'Compact Menu', 'mobile_menu' => 'Mobile Menu') );
?>