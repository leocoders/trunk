<?php 
	function separator() {
		return '<div class="separator"></div>';
	}
	add_shortcode("separator", "separator");
?>