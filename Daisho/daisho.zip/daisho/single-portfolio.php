<?php get_header(); ?>
<?php
$welcome_text 		= 	get_option("welcome_text");
$front_page 		= 	get_option('front_page');
	if($_GET['prj'] == 'classic') { $_SESSION['prj'] = 0; }
	if($_GET['prj'] == 'thumb') { $_SESSION['prj'] = 1; }
	$portfolio_mode 	= 	get_option('portfolio_mode'); // 1 = thumbnail grid, 0 = classic
	if(isset($_SESSION['prj']) && ($_SESSION['prj'] == 0)){ $portfolio_mode = 0; }
	if(isset($_SESSION['prj']) && ($_SESSION['prj'] == 1)){ $portfolio_mode = 1; }
	$portfolio_recent 	= 	get_option('portfolio_recent');
	$blog_recent 		= 	get_option('blog_recent');
	$post_id			=	esc_url(get_permalink($post->ID));
	$temp = $post;
if($front_page AND ($portfolio_mode == '0')){ $welcome_text_static = 'welcome-text-static'; }
?>

<?php if($welcome_text){ ?>
	<div class="welcome-text <?php echo $welcome_text_static; ?>"><?php echo $welcome_text; ?></div>
<?php } ?>

<?php if($portfolio_mode == '1'){ ?>
<style type="text/css">
@media (min-width: 950px) and (max-width: 1230px) {
	#header .inner, .welcome-text, #footer .inner, .footer-bottom, .tn-grid-container { width: 900px; }
}
@media (min-width: 750px) and (max-width: 950px) {
	#header .inner, .welcome-text, #footer .inner, .footer-bottom, .tn-grid-container { width: 675px; }
}
@media (max-width: 950px) {
	#main-nav-compact { display: none; } 
	.menu-mobile-menu-container { display: block; }
	#menu{ display: none; }
	#main-nav { margin-top: 25px; position: absolute; top: 0; width: 75%; }
	#header { min-height: 100px; position: fixed; border-bottom: 1px solid #AAAAAA; box-shadow: 0 0 8px #888888; }
	#header .inner { border-bottom: 0 none; min-height: 100px; }
	body { padding-top: 120px!important; }
	#footer .inner { display: none; }
	.homepage-project-list { position: static!important; border-bottom: 0 none; padding-top: 20px; margin-bottom: 20px !important; }
	#footer { position: relative; width: 100%;
	background-image: linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
	background-image: -o-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
	background-image: -moz-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
	background-image: -webkit-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
	background-image: -ms-linear-gradient(bottom, rgb(25,23,24) 0%, rgb(49,47,48) 100%);
	background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, rgb(25,23,24)), color-stop(1, rgb(49,47,48)));
	border-top: 1px solid #131313; box-shadow: 0px 5px 30px rgba(0,0,0,0.8); -webkit-box-shadow: -5px -5px 5px rgba(0,0,0,0.8); opacity:1; }
	#footer_copyright { float: left; width: 100%; text-align: center; padding-bottom: 0; font-size: 16px; }
	.footer_widgets { float: left; width: 100%; text-align: center; }
	.footer-bottom { margin: 8px auto 40px; }
	.footer-bottom-widgets { display: inline-block; float: none; margin-top: 15px; }
	#social { padding-bottom: 10px; padding-top: 12px; float: left; }
	#social a { float:left; position:relative; text-decoration:none; width:37px; height: 37px; clear:both; }
	#social li { float:left; width: 37px; margin-left: 22px; margin-right: 22px; }
	#social a span { cursor:pointer; display:block; left:0; position:absolute; top:0; font-size: 37px; color: #a6aAaB; }
	#footer {
		border-top: 1px solid #BBBBBB;
		background-image: linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -o-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -moz-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -webkit-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -ms-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #DADADA), color-stop(1, #F4F4F4));
		 box-shadow: 0 5px 30px rgba(0, 0, 0, 0.4);
		-webkit-box-shadow: -5px -5px 5px rgba(0, 0, 0, 0.15);
	}
	#header {
		background-image: linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -o-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -moz-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -webkit-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -ms-linear-gradient(bottom, #DADADA 0%, #F4F4F4 100%);
		background-image: -webkit-gradient( linear, left bottom, left top, color-stop(0, #DADADA), color-stop(1, #F4F4F4));
	}
}
</style>
<?php }else{ ?>
	<?php include('homepage-slideshow.php'); ?>
	<?php 
	if($page_id = $front_page){
		$page_data = get_page( $page_id );
		if(get_post_meta($page_data->ID, 'Description', true)){ ?>
			<div class="page-description" style="margin: 15px auto 50px;"><?php echo get_post_meta($page_data->ID, 'Description', true); ?></div>
		<?php } ?>
		<div class="page-content clearfix container_12"><?php echo do_shortcode($page_data->post_content); ?></div>
	<?php } ?>
<?php } $post = $temp; ?>

<nav id="main-nav-compact">
	<div class="clearfix main-nav-compact-inner">
		<a class="header-back-to-blog-link" href="<?php //bloginfo('url'); ?>javascript:void(null);"><div class="header-back-to-blog clearfix"><div class="header-back-to-blog-icon"></div><div class="header-back-to-blog-message"><?php _e('back', 'flowthemes'); ?></div></div></a>
		<?php wp_nav_menu( array( 'sort_column' => 'menu_order', 'theme_location'=>'main_menu', 'menu_class'=>'menu-compact', 'menu_id'=>'menu-compact', 'walker' => new compact_menu_walker() ) ); ?>
	</div>
</nav>
<div class="project-navigation" style="float: none;width:92%;max-width:1120px;margin:auto;z-index:99999999; position: fixed;right: 0;left:0;top:0;bottom:0;height: 80px;">
	<div class="scrollbar-arrowdleft portfolio-arrowleft">&lt;</div>
	<div class="scrollbar-arrowrdight portfolio-arrowright">&gt;</div>
</div>
<div class="portfolio_box current-slide" style="height: 100%; position: absolute; top: 0; left: 0; width: 100%; z-index: 22343393;">
	<div class="content-projectc contenttextwhite" id="content" style="float: none;width:92%;">
		<div style="opacity: 1;" class="project-excerpt">
			<ul class="project-meta">
				<?php if($date = get_post_meta($post->ID, 'portfolio_date', true)){ ?>
				<li class="project-date"><span class="project-meta-heading">DATE</span> <span class="project-exdate"><?php echo $date; ?></span></li>
				<?php } ?>
				<?php if($client = get_post_meta($post->ID, 'portfolio_client', true)){ ?>
				<li class="project-client"><span class="project-meta-heading">CLIENT</span> <span class="project-exclient"><?php echo $client; ?></span></li>
				<?php } ?>
				<?php if($agency = get_post_meta($post->ID, 'portfolio_agency', true)){ ?>
				<li class="project-agency"><span class="project-meta-heading">AGENCY</span> <span class="project-exagency"><?php echo $agency; ?></span></li>
				<?php } ?>
				<?php if($ourrole = get_post_meta($post->ID, 'portfolio_ourrole', true)){ ?>
				<li class="project-ourrole"><span class="project-meta-heading">OUR ROLE</span> <span class="project-exourrole"><?php echo $ourrole; ?></span></li>
				<?php } ?>
			</ul>
			<div class="socialikonsg">
				<a href="https://twitter.com/share?url=<?php print(esc_url(get_permalink($post->ID))); ?>&amp;text=<?php if($title = get_post_meta($post->ID, 'Title', true)){ print(urlencode($title)); }else{ print(urlencode(get_the_title($post->ID))); } ?>" class="twitter" style="color:<?php if($portfoliotextcolorfl=='#ffffff'){print("#ffffff");}else{print("#000000");} ?>;" title="Twitter">t</a>
				<a href="http://www.facebook.com/sharer.php?u=<?php print(esc_url(get_permalink($post->ID))); ?>&amp;t=<?php if($title = get_post_meta($post->ID, 'Title', true)){ print(urlencode($title)); }else{ print(urlencode(get_the_title($post->ID))); } ?>" class="facebook" style="color:<?php if($portfoliotextcolorfl=='#ffffff'){print("#ffffff");}else{print("#000000");} ?>;" title="Facebook">f</a>
				<a href="https://plus.google.com/share?url=<?php print(esc_url(get_permalink($post->ID))); ?>" style="color:<?php if($portfoliotextcolorfl=='#ffffff'){print("#ffffff");}else{print("#000000");} ?>;" class="googleplus" title="Google+">g</a>
			</div>
			<div style="clear:both;"></div>
			<h1 style="letter-spacing:-4px;float:left;" class="project-title"><?php if(get_post_meta($post->ID, 'Title', true)){ echo get_post_meta($post->ID, 'Title', true); }else{ the_title(); } ?></h1>
			<div style="float:left;margin: 14px 0 0 10px;" class="project-meta project-cats"></div>
			<div style="clear:both;"></div>
			<h4 class="project-description"><?php if(get_post_meta($post->ID, 'Description', true)){ echo get_post_meta($post->ID, 'Description', true); } ?></h4>
			<div class="project-slides"><?php $this_page = get_page($post->ID); echo do_shortcode($this_page->post_content); ?></div>
		</div>
		<div class="clear"></div>
	</div>
</div>
<div class="project-coverslide" style="position: fixed; top: 0; left: 0; z-index:2234332;"></div>

<?php if($portfolio_mode == '1'){ ?>
<div class="tn-grid-container">
<section id="content">
	<section id="options" class="clearfix">
		<?php
			$taxonomy = 'portfolio_category';
			$tax_terms = get_terms($taxonomy);
		?>
		<ul id="filters" class="option-set clearfix" data-option-key="filter">
			<li><a href="#filter" data-option-value="*" class="selected">All works</a></li>
			<?php
				foreach ($tax_terms as $tax_term) {
					echo '<li>' . '<a href="#filter" data-option-value=".' . strtolower(str_replace(" ", "-", $tax_term->name)) . '">' . $tax_term->name  . '</a></li>';
				}
			?>
		</ul>
		<ul id="etc" class="clearfix">
			<li id="toggle-sizes"><a href="#toggle-sizes" class="toggle-selected">Toggle variable sizes</a><a href="#toggle-sizes">Toggle variable sizes</a></li>
			<!-- <li id="shuffle"><a href='#shuffle'>Shuffle</a></li> -->
		</ul>
	</section> <!-- #options -->

<div id="container" class="clickable variable-sizes clearfix">
<?php } ?>
<?php 
	$count = 0;
	$i = -1;
	$r = 0;
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$post_per_page = -1;
	$do_not_show_stickies = 1; // 0 to show stickies
	$pf_categorynotin = get_post_meta($wp_query->post->ID, "exclude-pf-categories", true);
  
	$args=array(
		'post_type' => array ('portfolio'),
		'orderby' => $orderby,
		'order' => 'DESC',
		'paged' => $paged,
		'posts_per_page' => $post_per_page,
		'ignore_sticky_posts' => $do_not_show_stickies
	);
	if($pf_categorynotin){
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'portfolio_category',
				'field' => 'slug',
				'terms' => $pf_categorynotin,
				'operator' => 'NOT IN'
			)
		); //category__in
	}

	$temp = $wp_query;  // assign orginal query to temp variable for later use   
	$wp_query = null;
	$wp_query = new WP_Query($args);
	$fg_image = '';
	$fg_imagemain = '';
	if( have_posts() ) : 
		while ($wp_query->have_posts()) : $wp_query->the_post();
		
			/* Get post categories */
			$post_cat = array();
			$post_cat = wp_get_object_terms($post->ID, "portfolio_category");
			$post_cats = array();
			$post_rel = ' all ';
			for($h=0;$h<count($post_cat);$h++){
				$post_rel .= $post_cat[$h]->slug.' ';
				$post_cats[] = $post_cat[$h]->name;
			}
			
			/* Get and process image */
			unset($attachments);
			unset($thumbnail_hover_color);
			$attachments = get_post_meta($post->ID, '300-160-image', true);
			$thumbnail_hover_color = get_post_meta($post->ID, 'thumbnail_hover_color', true);
			$image_resizer_output = '';
			if($width = get_post_meta($post->ID, 'image_width', true)) { $image_resizer_output.= 'width='.$width.'&amp;';}else{$image_resizer_output.= 'width=400&amp;';}
			if($height = get_post_meta($post->ID, 'image_height', true)) { $image_resizer_output.= 'height='.$height.'&amp;';}else{$image_resizer_output.= 'height=300&amp;';}
			if($crop_ratio_x_y = get_post_meta($post->ID, 'crop_ratio_x_y', true)) { $image_resizer_output.= 'cropratio='.$crop_ratio_x_y.'&amp;';}else{$image_resizer_output.= 'cropratio=4:3&amp;';}
			$image_resizer_output2 = 'width=1120&amp;';
			if ($attachments or $thumbnail_hover_color) {
				$post_cat = array();
				$post_cat = wp_get_object_terms($post->ID, "portfolio_category");
				$post_cats = array();
				for($h=0;$h<count($post_cat);$h++){
					$post_cats[] = $post_cat[$h]->name;
				}
				$cats_pf_this = implode(", ", $post_cats);
				$cats_pf_this_class = strtolower(implode(" ", str_replace(" ", "-", $post_cats)));
				$cprojvalid = false;
				if(get_post_meta($post->ID, 'Title', true)){
					$cprojvalid = true;
					$thumb_title = get_post_meta($post->ID, 'Title', true);
				}else{
					$thumb_title = get_the_title(); 
				}
				$thumb_descr = get_post_meta($post->ID, 'Description', true);
				$tmpddourrole = get_post_meta($post->ID, 'portfolio_ourrole', true);
				$tmpdddate = get_post_meta($post->ID, 'portfolio_date', true);
				$tmpddclient = get_post_meta($post->ID, 'portfolio_client', true);
				$tmpddagency = get_post_meta($post->ID, 'portfolio_agency', true);
				$tmpddbgimg = get_post_meta($post->ID, 'bg_image', true);
				$tmpddtxtcolor = get_post_meta($post->ID, 'portfolio_text_color', true);
				$tmpddsize = get_post_meta($post->ID, 'thumbnail_size', true);
				$tmpdddisplay = get_post_meta($post->ID, 'thumbnail_meta', true);
				if($tmpdddisplay == 1){ $tmpdddisplay = 'tn-display-meta'; }else{ $tmpdddisplay = ''; }
				$tmpddslides = get_post_meta($post->ID, 'slides', true);
				$resizepath_mobile = get_bloginfo('template_directory').'/image.php?'.str_replace('&amp;', '&', $image_resizer_output).'image=http';
				$resizepath_desktop = get_bloginfo('template_directory').'/image.php?'.str_replace('&amp;', '&', $image_resizer_output2).'image=http';
				if(preg_match('/\.(bmp|jpg|jpeg|pjpeg|png|gif)$/i',$tmpddslides)){
					if($mobile){ $tmpddslides = str_replace('http', $resizepath_mobile , $tmpddslides); }else{ $tmpddslides = str_replace('http', $resizepath_desktop , $tmpddslides); }
				}
				
				// Set thumbnail sizes
				// Empty(small); 0(random); 1(large); 1,5(horizontal); 2,4(small); 3(medium); 6(vertical)

				unset($tmpddvertical);
				if($tmpddsize == ''){ $tmpddsize = rand(2,11);
				}else if($tmpddsize == '0'){ $tmpddsize = rand(2,11); 
				}else if($tmpddsize == '1'){ $tmpddsize = 7; 
				}else if($tmpddsize == '2'){ $tmpddsize = 3;
				}else if($tmpddsize == '3'){ $tmpddsize = 6;
				}else if($tmpddsize == '4'){ $tmpddsize = 5;
				}else if($tmpddsize == '5'){ $tmpddsize = 2; 
				}else{ $tmpddsize = 2; }
				if($tmpddsize == 6 or $tmpddsize == 9){ $tmpddvertical = 'vertical-thumbnail'; }

				$i++;
				$r++;
				
				if($portfolio_mode == '0' AND $r <= 5){ //Static Homepage portfolio enabled.
					unset($element_image);
					if($attachments){
						$element_image = '<img class="project-img" style="z-index: 1;" src="'.$attachments.'" alt="" />';
					}
					$element_small .= '<div class="element element-stand-alone '.$tmpdddisplay.'">
						<p class="number" style="z-index:3;">'.$tmpddsize.'</p>
						<h3 class="symbol" style="z-index:3;">'.$thumb_title.'</h3>
						<h2 class="name" style="z-index:3;">'.$tmpddclient.'</h2>
						<h2 class="categories" style="z-index:3;">'.$cats_pf_this.'</h2>
						<p class="id" style="display:none;">'.$i.'</p>
						<div style="background-color:'.$thumbnail_hover_color.'; width: 100%; height: 100%; z-index: 2;" class="thumbnail-hover"></div>
						'.$element_image.'
						<div style="background-color:'.$thumbnail_hover_color.'; width: 100%; height: 100%;z-index:0;"></div>
					</div>';
				}else if($portfolio_mode == '1'){ ?>
				
			<div class="element <?php echo $cats_pf_this_class; ?> <?php if(isset($tmpddvertical)){ echo $tmpddvertical; } ?> <?php echo $tmpdddisplay; ?>" data-symbol="Mg" data-category="alkaline-earth">
				<p class="number"><?php echo $tmpddsize; ?></p>
				<h3 class="symbol"><?php echo $thumb_title; ?></h3>
				<h2 class="name"><?php echo $tmpddclient; ?></h2>
				<h2 class="categories"><?php echo $cats_pf_this; ?></h2>
				<p class="id" style="display:none;"><?php echo $i; ?></p>
				<div style="background-color: <?php echo $thumbnail_hover_color ?>; width: 100%; height: 100%;" class="thumbnail-hover"></div>
				<?php if($attachments){ ?>
					<img class="project-img" src="<?php echo $attachments; ?>" alt="" />
				<?php } ?>
				<div style="background-color: <?php echo $thumbnail_hover_color ?>; width: 100%; height: 100%;z-index:-2;"></div>
			</div>
			<?php }
			$portfolioArray .='
				portfolioArray['.$i.'] = [];
				portfolioArray['.$i.'][0]="'.$thumb_title.'";
				portfolioArray['.$i.'][1]="'.$thumb_descr.'";
				portfolioArray['.$i.'][2]="'.$tmpdddate.'";
				portfolioArray['.$i.'][3]="'.$tmpddclient.'";
				portfolioArray['.$i.'][4]="'.$tmpddagency.'";
				portfolioArray['.$i.'][5]="'.$tmpddourrole.'";
				portfolioArray['.$i.'][6]="'.preg_replace("/(\n|\r|\r\n)/", '', str_replace("\"","\\\"",do_shortcode($tmpddslides))).'";
				portfolioArray['.$i.'][7]="'.get_permalink( $post->ID ).'";
				';
			?>
			<?php } //if image exists, project is valid ?>
			<?php endwhile ?>
			<?php else : ?>
				<h2 class="center"><?php _e('Not Found', 'flowthemes'); ?></h2>
				<p class="center"><?php _e('Sorry, but you are looking for something that isn\'t here.', 'flowthemes'); ?></p>
			<?php endif; $wp_query = $temp;  //reset back to original query ?>
<?php if($portfolio_mode == '1'){ ?>
</div> <!-- /#container -->
</section>
</div>
<?php } ?>

<?php if($portfolio_mode == '1'){ }else{ ?>
	<?php if($portfolio_recent == '1'){ }else{ ?>
		<div class="recent-heading-container clearfix">
		<div class="recent-heading"><!--<span class="spacer"></span>--><h1><?php _e('Recent Projects', 'flowthemes'); ?></h1><span class="spacer"></span><a href="#"><?php _e('View Portfolio', 'flowthemes'); ?></a></div><div id="content-small" style="margin-top: 15px;" class="clearfix"><?php echo $element_small; ?></div></div>
	<?php } ?>

	<?php if($blog_recent == '1'){ }else{ ?>
	<div style="max-width:1120px; width: 92%; margin: 0 auto -3px; padding-top: 15px; clear:both; position: relative;" class="clearfix recent-blog-container">
	<div class="recent-heading"><!--<span class="spacer"></span>--><h1><?php _e('New Blog Posts', 'flowthemes'); ?></h1><span class="spacer"></span><a href="#"><?php _e('View Blog', 'flowthemes'); ?></a></div><div style="margin-top: 15px; background-color:#eeeeee;" class="clearfix">
		<div class="related-posts related-posts-home clearfix" style="border: none; max-width: 1120px; width: 100%; margin: 0 auto;">
			<?php wp_reset_query();
			query_posts('posts_per_page=4');
			if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="related-posts-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a><small><?php the_time('F jS, Y'); ?></small></div>
			<?php endwhile; else: _e("No posts found.", 'flowthemes'); endif; wp_reset_query(); ?>
		</div>
		</div></div>
	<?php } ?>
<?php } ?>

<script type="text/javascript">
var portfolioArray = [];
<?php echo $portfolioArray; ?>

var portfolioArrayValid = [];
for(var pai=0;pai<portfolioArray.length;pai++){
	if(portfolioArray[pai][6]){
		portfolioArrayValid[portfolioArrayValid.length] = portfolioArray[pai];
	}
}

$ = jQuery.noConflict();
	
	function bringPortfolio( current_id ) {
	  if(portfolioArrayValid[current_id] === undefined){ if(portfolioArrayValid.length != 0){ bringPortfolio( 0 ); } return; }
	  var title = portfolioArrayValid[current_id][0];
	  if(title == ''){ var title = 'Title not specified'; }
	  var desc = portfolioArrayValid[current_id][1];
	  var date = portfolioArrayValid[current_id][2];
	  var client = portfolioArrayValid[current_id][3];
	  var agency = portfolioArrayValid[current_id][4];
	  var ourrole = portfolioArrayValid[current_id][5];
	  var slides = portfolioArrayValid[current_id][6];
	  var permalink = portfolioArrayValid[current_id][7];
	  var number_of_ids = portfolioArrayValid.length;

	   $('.current-slide #content').animate({"opacity" : 0 }, 300, function(){
	    if(date == ''){ $('.project-date').hide(); }else{ $('.project-date').show(); }
	    if(client == ''){ $('.project-client').hide(); }else{ $('.project-client').show(); }
	    if(agency == ''){ $('.project-agency').hide(); }else{ $('.project-agency').show(); }
	    if(ourrole == ''){ $('.project-ourrole').hide(); }else{ $('.project-ourrole').show(); }

		$(this).animate({ "opacity" : 1}, 300);
		$('.portfolio_box').css({ 'display' : 'block' }).animate({ 'opacity' : 1 }, 700);
		$('#main-nav-compact').css({ 'display' : 'block' }).animate({ 'opacity' : 1 }, 700);
		$('.project-coverslide').css({ 'display' : 'block' }).animate({ 'opacity' : 0.97 }, 700);
		$('.project-navigation').css({ 'display' : 'block' }).animate({ 'opacity' : 1 }, 700);
		$('.project-title').html(title);
		$('.project-description').html(desc);
		$('.project-exdate').html(date);
		$('.project-exclient').html(client);
		$('.project-exagency').html(agency);
		$('.project-exourrole').html(ourrole);
		$('.project-slides').html(slides);
		$('.project-slides').find('img').each(function(){
			$(this).wrap("<div class=\"project-slides-container\"></div>");
			if((($(this).attr('data-title') != '') && ($(this).attr('data-title') != '<h4></h4>')) && ($(this).attr('data-title') != undefined)){ $(this).after('<span style="opacity:0;">'+$(this).attr('data-title').replace("</h4>", "</h4><p>")+'</p></span>'); $(this).next('span').delay(800).css({"opacity" : 1}); }
		});
		  if(!jQuery.browser.msie){
			 window.history.pushState({}, title, permalink);
		  }
		if(jQuery(".socialikonsg").length){
			try{
				jQuery(".socialikonsg a[title]").tooltip({"position": "bottom center", "tipClass": "jqttooltip", "effect":"r_fadeslide"});
			}catch(e){}
			jQuery(".socialikonsg .twitter").attr("href", "https://twitter.com/share?url="+escape(window.location.href)+"&amp;text=");//+escape(datatitle));
			jQuery(".socialikonsg .facebook").attr("href", "http://www.facebook.com/sharer.php?u="+escape(window.location.href)+"&amp;t=");//+escape(datatitle));
			jQuery(".socialikonsg .googleplus").attr("href", "https://plus.google.com/share?url="+escape(window.location.href));
		}
		setTimeout(function(){
		try{
			VideoJS.setupAllWhenReady();
			videojsvolumemuteclick();
		}catch(e){}
		}, 500);
		$('body,html').animate({scrollTop:0},800);
		$('.portfolio-arrowright').unbind();
		$('.portfolio-arrowleft').unbind();
		$('.portfolio-arrowright').click(function(){
			current_id++; if(current_id == number_of_ids){ current_id = 0; }
			bringPortfolio( current_id );
		});
		$('.portfolio-arrowleft').click(function(){
			current_id--; if(current_id == -1){ current_id = number_of_ids-1; }
			bringPortfolio( current_id );
		});
	   }); //animate opaciy 0 (.current-slide #content)
    }
$(function(){
    
    var $container = $('#container');
    var $containerSmall = $('#content-small');
    
    
      // add randomish size classes
      $container.find('.element').each(function(){
        var $this = $(this),
            number = parseInt( $this.find('.number').text(), 10 );
        if ( number % 7 % 2 === 1 ) {
          $this.addClass('width2');
        }
        if ( number % 3 === 0 ) {
          $this.addClass('height2');
        }        
		if ( number % 7 === 0 ) { //Rare because it picks random number from 1 to 11 and only 7 matches criteria
          $this.addClass('width3');
          $this.addClass('height2');
        }
      });
	  
	// center images inside elements
	function centerIsotypeImages(){
		$('.element').each(function(){
			var $this = $(this);
			if($this.find('img').get(0) === undefined){ return; }
			var cont_ratio = $this.width() / $this.height();
			var img_ratio = $this.find('img').get(0).width / $this.find('img').get(0).height;

			if(cont_ratio <= img_ratio){
				$this.find('img').css({ 'width' : 'auto', 'height' : '100%', 'top' : 0 }).css({ 'left' : ~(($this.find('img').width()-$this.width())/2)+1 });
				$this.find('img').stop(true, true).fadeIn(200);
			}else{
				$this.find('img').css({ 'width' : '100%', 'height' : 'auto', 'left' : 0 }).css({ 'top' : ~(($this.find('img').height()-$this.height())/2)+1 });
				$this.find('img').stop(true, true).fadeIn(200);
			}
		});
	}
	$(window).load(function(){
		centerIsotypeImages();
		if(jQuery(".socialikonsg").length){
			try{
				jQuery(".socialikonsg a[title]").tooltip({"position": "bottom center", "tipClass": "jqttooltip", "effect":"r_fadeslide"});
			}catch(e){}
		}
	});
	
	var number_of_ids = portfolioArrayValid.length;
	if(number_of_ids >= 1){
		for(var current_id = 0;current_id<number_of_ids;current_id=current_id+1){
			if(portfolioArrayValid[current_id][7] == '<?php echo $post_id; ?>'){
				$('.portfolio-arrowright').click(function(){ current_id++; if(current_id == number_of_ids){ current_id = 0; } bringPortfolio( current_id ); });
				$('.portfolio-arrowleft').click(function(){ current_id--; if(current_id == -1){ current_id = number_of_ids-1; } bringPortfolio( current_id ); });
				break;
			}
		}
	}

/*	$(".project-img").one("load",function(){
		var $this = $(this);
		var cont_ratio = $this.parent().width() / $this.parent().height();
		var img_ratio = $this.get(0).width / $this.get(0).height;
		if(cont_ratio <= img_ratio){
			$this.css({ 'width' : 'auto', 'height' : '100%', 'top' : 0 }).css({ 'left' : ~(($this.width()-$this.parent().width())/2) });
		}else{
			$this.css({ 'width' : '100%', 'height' : 'auto', 'left' : 0 }).css({ 'top' : ~(($this.height()-$this.parent().height())/2) });
		}
	})
	.each(function(){
	if(this.complete || (jQuery.browser.msie && parseInt(jQuery.browser.version) == 6)) 
		$(this).trigger("load");
	}); */
    
    $container.isotope({
      itemSelector : '.element',
      masonry : {
        //columnWidth : 120
        columnWidth : 5,
		gutterWidth: 5,
      },
      masonryHorizontal : {
        rowHeight: 120
      },
      cellsByRow : {
        columnWidth : 240,
        rowHeight : 240
      },
      cellsByColumn : {
        columnWidth : 240,
        rowHeight : 240
      },
      getSortData : {
        symbol : function( $elem ) {
          return $elem.attr('data-symbol');
        },
        category : function( $elem ) {
          return $elem.attr('data-category');
        },
        number : function( $elem ) {
          return parseInt( $elem.find('.number').text(), 10 );
        },
        weight : function( $elem ) {
          return parseFloat( $elem.find('.weight').text().replace( /[\(\)]/g, '') );
        },
        name : function ( $elem ) {
          return $elem.find('.name').text();
        }
      }
    });
    
    
      var $optionSets = $('#options .option-set'),
          $optionLinks = $optionSets.find('a');

      $optionLinks.click(function(){
        var $this = $(this);
        // don't proceed if already selected
        if ( $this.hasClass('selected') ) {
          return false;
        }
        var $optionSet = $this.parents('.option-set');
        $optionSet.find('.selected').removeClass('selected');
        $this.addClass('selected');
  
        // make option object dynamically, i.e. { filter: '.my-filter-class' }
        var options = {},
            key = $optionSet.attr('data-option-key'),
            value = $this.attr('data-option-value');
        // parse 'false' as false boolean
        value = value === 'false' ? false : value;
        options[ key ] = value;
        if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
          // changes in layout modes need extra logic
          changeLayoutMode( $this, options )
        } else {
          // otherwise, apply new options
          $container.isotope( options );
        }
        
        return false;
      });


    
      // change layout
      var isHorizontal = false;
      function changeLayoutMode( $link, options ) {
        var wasHorizontal = isHorizontal;
        isHorizontal = $link.hasClass('horizontal');

        if ( wasHorizontal !== isHorizontal ) {
          // orientation change
          // need to do some clean up for transitions and sizes
          var style = isHorizontal ? 
            { height: '80%', width: $container.width() } : 
            { width: 'auto' };
          // stop any animation on container height / width
          $container.filter(':animated').stop();
          // disable transition, apply revised style
          $container.addClass('no-transition').css( style );
          setTimeout(function(){
            $container.removeClass('no-transition').isotope( options );
          }, 100 )
        } else {
          $container.isotope( options );
        }
      }

    
      // close bringPortfolio()
      $('#main-nav-compact').delegate( '.header-back-to-blog-link', 'click', function(){
		$('.portfolio_box').css({ 'display' : 'none', 'opacity' : 0 });
		$('#main-nav-compact').css({ 'display' : 'none', 'opacity' : 0 });
		$('.project-coverslide').css({ 'display' : 'none', 'opacity' : 0 });
		$('.project-navigation').css({ 'display' : 'none', 'opacity' : 0 });
		$('.project-slides').empty();
		if(!jQuery.browser.msie){
			var document_title = "<?php bloginfo('name'); ?><?php wp_title('-'); ?>";
			var portfoliohistorywpurl = "<?php $biurl=substr(get_bloginfo("url"),7);if(strpos($biurl,"/")!==false){print(substr($biurl,strpos($biurl,"/")+1));} ?>";
			window.history.pushState({}, document_title, ((portfoliohistorywpurl)?("/"+portfoliohistorywpurl+"/"):""));
		}
      });      
	  
		// change size of clicked element
		$container.delegate( '.element', 'click', function(){
			var current_id = $(this).find('.id').text();
			bringPortfolio(current_id);
			//  $(this).toggleClass('large');
			//  $container.isotope('reLayout', centerIsotypeImages);
		});		
		
		// change size of clicked element (small)
		$containerSmall.delegate( '.element', 'click', function(){
			var current_id = $(this).find('.id').text();
			bringPortfolio(current_id);
		});
	  

      // toggle variable sizes of all elements
      $('#toggle-sizes').find('a').click(function(){
	  if($(this).hasClass('toggle-selected')){ return false; }
		$('#toggle-sizes').find('a').removeClass('toggle-selected');
		$(this).addClass('toggle-selected');
		if(!$('#toggle-sizes a:first-child').hasClass('toggle-selected')){ $container.find('.element').addClass('element-small'); }else{ $container.find('.element').removeClass('element-small'); }
		$container.find('img').fadeOut(0);
        $container
          .toggleClass('variable-sizes')
          .isotope('reLayout');
          centerIsotypeImages();
        return false;
      });

    
      $('#insert a').click(function(){
        var $newEls = $( fakeElement.getGroup() );
        $container.isotope( 'insert', $newEls );

        return false;
      });

      $('#append a').click(function(){
        var $newEls = $( fakeElement.getGroup() );
        $container.append( $newEls ).isotope( 'appended', $newEls );

        return false;
      });


    var $sortBy = $('#sort-by');
    $('#shuffle a').click(function(){
      $container.isotope('shuffle');
      $sortBy.find('.selected').removeClass('selected');
      $sortBy.find('[data-option-value="random"]').addClass('selected');
      return false;
    });


  });
</script>

<?php get_footer(); ?>